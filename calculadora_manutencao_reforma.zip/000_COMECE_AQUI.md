# 🚀 000_COMECE_AQUI — BOOT + ROM DO FRAMEWORK SENSIENTE

## Protocolo de Inicialização
1. Este arquivo deve ser lido antes de qualquer outro.
2. Não gerar resumo, interpretação subjetiva ou comentários não solicitados.
3. Todos os arquivos do pacote devem ser processados internamente.

## Objetivo do Projeto
Implementar uma calculadora de manutenção e reforma de estruturas metálicas modulares, com persistência em XML e arquitetura pronta para expansão para banco de dados (ex: NocoDB).

---
